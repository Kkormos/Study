//
//  ViewController.swift
//  PickerF
//
//  Created by Krisztian Kormos on 17/11/2016.
//  Copyright © 2016 Krisztian Kormos. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UIPickerViewDataSource, UIPickerViewDelegate {

    @IBOutlet weak var selectChange: UIButton!
    @IBOutlet weak var pickerView: UIPickerView!
    
    
    var selectBtnChange = true
    var selection = ["Page 1", "Page 2", "Page 3"]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        pickerView.dataSource = self
        pickerView.delegate = self
        
        
    }

    @IBAction func selectBtn(_ sender: Any) {
    
        if selectChange.titleLabel?.text == "Page 1" {
        performSegue(withIdentifier: "green", sender: self)
            
        } else if selectChange.titleLabel?.text == "Page 2" {
            performSegue(withIdentifier: "red", sender: self)
        
        } else {
            performSegue(withIdentifier: "blue", sender: self)
            }
        
    }
  
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return selection.count
        
        
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        
               let selected = selection[row]
        
        return selected
    }
    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        
        let selected = selection[row]
       
        
        selectChange.setTitle(selected, for: .normal)
        

    }
   
}



