//
//  ViewController.swift
//  pickerViewno2
//
//  Created by Krisztian Kormos on 13/11/2016.
//  Copyright © 2016 Krisztian Kormos. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UIPickerViewDataSource, UIPickerViewDelegate {

    var contents : [String] = ["Shooting Checklist", "Camera Modes", "Exposure", "ISO", "Shutter Speed", "Aperture", "White Balance", "BULB/Back Button Focus", "Lens", "Achieving Sharp Photos", "Sunny 16 Rule", "Undrestanding Histograms", "Composition", "Glossary of Terms"]
    
    
    @IBOutlet weak var pickerView: UIPickerView!
    @IBOutlet weak var label: UILabel!
    
    
        override func viewDidLoad() {
        super.viewDidLoad()
        
        pickerView.dataSource = self
        pickerView.delegate = self
        
        // Do any additional setup after loading the view, typically from a nib.
    }

    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return contents.count
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        
        let myContents = contents[row]
        print(myContents)
        
        label.text = "\(myContents)"
        
        return myContents
    }
}

