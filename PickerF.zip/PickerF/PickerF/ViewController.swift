//
//  ViewController.swift
//  PickerF
//
//  Created by Krisztian Kormos on 17/11/2016.
//  Copyright © 2016 Krisztian Kormos. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UIPickerViewDataSource, UIPickerViewDelegate {

    @IBOutlet weak var pickerView: UIPickerView!
    
    var selection = ["Page 1", "Page 2", "Page 3"]
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        pickerView.dataSource = self
        pickerView.delegate = self
        
        
    }

    @IBAction func SelectionBtn(_ sender: Any) {
        
//        let row = pickerView.selectedRow(inComponent: 0)
//        
//        switch (row) {
//            
//        case 0: self.performSegue(withIdentifier: "red", sender: self)
//        break;
//        case 1: self.performSegue(withIdentifier: "blue", sender: self)
//        break;
//        case 2: self.performSegue(withIdentifier: "green", sender: self)
//        break;
//        default: break;
//            
//        }
        
        
        
        
            }
  
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return selection.count
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        let selected = selection[row]
        
        return selected
    }
    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        
                if (row == 0) {
        
        performSegue(withIdentifier: "red", sender: self)
        }
        else if (row == 1) {
            
        performSegue(withIdentifier: "blue", sender: self)
        }
        else {
        performSegue(withIdentifier: "green", sender: self)
        
        }

    }
   
}



