//
//  DetailVC.swift
//  TableViewDemo
//
//  Created by Krisztian Kormos on 24/11/2016.
//  Copyright © 2016 Krisztian Kormos. All rights reserved.
//

import UIKit

class DetailVC: UIViewController {

    var fillup = "Empty"
    
    
    @IBOutlet weak var label: UILabel!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        
       label.text = fillup
        
        
        
    }

  
}
